import json
import numpy as np 
import os

text_id=0
output_path=''

def _parse_data(fh):
    data=fh.readlines()
    # string=fh.read().decode('utf-8')
    # print(string)
    # data = string.split('\n')
    fh.close()
    return data

def labels_class(labels):
    label={}
    for i in labels:
        if label.get(i[2])!=None:
            label[i[2]].append(i[:2])
        else:
            label[i[2]]=[i[:2]]
    return label

def read_json(output_path,text_id):
    text_path=os.path.join(os.getcwd(),'annotation','json','text'+str(text_id)+'_'+str(text_id+1)+'.json1')
    with open(text_path) as f:
        data=_parse_data(f)

    for j in data:
        json_dict=json.loads(j)
        text=list(json_dict['text'].replace(' ',''))
        labels=list(json_dict['labels'])
        label=labels_class(labels)
        outlabels=['O' for it in range(len(text))]
        for l in label['CL']:
            outlabels[l[0]]='B-CL'
            for i in range(l[0]+1,l[1]):
                outlabels[i]='I-CL'
        #根据O标签找出无用文本段进行删除
        label_O=label.get('O')
        if label_O!=None and len(label_O) ==2:
            B=label_O[0][0]
            E=label_O[1][0]
            del outlabels[B:E]
            del text[B:E]
        with open(output_path,'a+') as f:
            for i in range(len(text)):
                s=text[i]+' '+outlabels[i]+'\n'
                if text[i]=='。':
                    s=s+'\n'
                f.write(s)
                # if i!=0 and i % 300 ==0 :
                #     f.write('\n')

if __name__=='__main__':
    B=2
    E=7
    output_path=os.path.join(os.getcwd(),'annotation','output','train_data','train'+str(B)+'_'+str(E)+'.data')
    fh=open(output_path,'w')
    fh.close()
    for i in range(B,E):
        if i % 2 ==0:
            text_id=i
        read_json(output_path,text_id)
