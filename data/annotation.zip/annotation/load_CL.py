import numpy as np 
import os

def _parse_data(fh):
    string=fh.read().decode('utf-8')
    data = string.split('\n')
    fh.close()
    return data

def transfer(file_name,output_path):
    fh=open('source_TXT/'+file_name+'.txt','rb')
    data = _parse_data(fh)
    data = data[9:]
    for i in range(len(data)-1,0,-1):
       if('。' in data[i] ):
            break
       else:
            del data[i]

    output=open(output_path,'a+')
    for i in data :
        output.write(i)
    #'\n'分割样本
    output.write('\n')
    output.close()

if __name__=='__main__':
    output_id=0
    output_path=''
    for i in range(1,111):
        #每十组样本整合到一个text中
        if i % 10 ==1:
            output_id=int(i/10)
            output_path=os.path.join(os.getcwd(),'output','CL_output','CL_text'+str(output_id)+'.txt')
        #创建对应文件
            fh=open(output_path,'w')
            fh.close
        fn="CL"+str(i)
        transfer(fn,output_path)